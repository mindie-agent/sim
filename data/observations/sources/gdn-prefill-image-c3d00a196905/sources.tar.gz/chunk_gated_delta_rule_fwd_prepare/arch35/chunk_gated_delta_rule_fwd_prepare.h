/**
 * Copyright (c) 2026 Tianjin University, Ltd.
 * BSD 3-Clause License.
 *
 * Fused GDN prepare (arch35 MIX AIC:AIV 1:2). Helpers in *_common/vf/datacopy/matmul.
 * Memory map: design/chunk_gated_delta_rule_fwd_prepare_ascendc-design.md.
 *
 * Pack: TG = 3 if G=3 else 4. AIV0 tasks 0,2; AIV1 1,3. kkt once per HK (OwnsHk).
 * L1: Y [0,64); k' aliases NegL [64,128). Pack N+1 Stage1 waits pack N Stage4
 * before the k' L1 write so Stage5/6/7 of N can overlap next Stage1.
 * Do not gate Stage1 on Stage7: that kills the overlap and regresses G=1.
 */

#ifndef CHUNK_GATED_DELTA_RULE_FWD_PREPARE_H
#define CHUNK_GATED_DELTA_RULE_FWD_PREPARE_H

#include "kernel_operator.h"
#include "chunk_gated_delta_rule_fwd_prepare_common.h"
#include "chunk_gated_delta_rule_fwd_prepare_vf.h"
#include "chunk_gated_delta_rule_fwd_prepare_datacopy.h"
#include "chunk_gated_delta_rule_fwd_prepare_matmul.h"

namespace ChunkGatedDeltaRuleFwdPrepare {
using namespace AscendC;
using namespace AscendC::MicroAPI;

template <typename GateDtype, typename ALogDtype>
class ChunkGatedDeltaRuleFwdPrepareKernel : public PrepareState {
public:
    using InDtype = bfloat16_t;

    template <typename Td>
    __aicore__ inline void Init(GM_ADDR q, GM_ADDR k, GM_ADDR v, GM_ADDR g, GM_ADDR beta, GM_ADDR aLog, GM_ADDR dtBias,
                                GM_ADDR cu, GM_ADDR idx, GM_ADDR gOut, GM_ADDR wOut, GM_ADDR uOut, GM_ADDR aOut,
                                GM_ADDR qHat, GM_ADDR kHat, GM_ADDR qRstd, GM_ADDR kRstd, GM_ADDR betaEff,
                                GM_ADDR workspace, const Td &td)
    {
        LoadTiling(td);
        InitOnChip();
        GM_ADDR userWs = GetUserWorkspace(workspace);
        const uint32_t wsBase = static_cast<uint32_t>(coreIdx) * kWsPerCoreBytes;
        if (userWs != nullptr) {
            gmWsY.SetGlobalBuffer(reinterpret_cast<__gm__ float *>(userWs + wsBase),
                                  kWsYSlots * kWsYElems);
        } else {
            gmWsY.SetGlobalBuffer(reinterpret_cast<__gm__ float *>(uOut));
        }
        gmQ.SetGlobalBuffer(reinterpret_cast<__gm__ InDtype *>(q));
        gmK.SetGlobalBuffer(reinterpret_cast<__gm__ InDtype *>(k));
        gmV.SetGlobalBuffer(reinterpret_cast<__gm__ InDtype *>(v));
        gmG.SetGlobalBuffer(reinterpret_cast<__gm__ GateDtype *>(g));
        gmBeta.SetGlobalBuffer(reinterpret_cast<__gm__ GateDtype *>(beta));
        if (aLog != nullptr) {
            gmALog.SetGlobalBuffer(reinterpret_cast<__gm__ ALogDtype *>(aLog));
        }
        if (dtBias != nullptr) {
            gmDt.SetGlobalBuffer(reinterpret_cast<__gm__ ALogDtype *>(dtBias));
        }
        if (cu != nullptr) {
            gmCu.SetGlobalBuffer(reinterpret_cast<__gm__ int64_t *>(cu));
        }
        if (idx != nullptr) {
            gmIdx.SetGlobalBuffer(reinterpret_cast<__gm__ int64_t *>(idx));
        }
        gmGOut.SetGlobalBuffer(reinterpret_cast<__gm__ float *>(gOut));
        gmW.SetGlobalBuffer(reinterpret_cast<__gm__ InDtype *>(wOut));
        gmU.SetGlobalBuffer(reinterpret_cast<__gm__ InDtype *>(uOut));
        if (outputA != 0) {
            gmA.SetGlobalBuffer(reinterpret_cast<__gm__ InDtype *>(aOut));
        }
        if (useQkL2norm != 0) {
            gmQHat.SetGlobalBuffer(reinterpret_cast<__gm__ InDtype *>(qHat));
            gmKHat.SetGlobalBuffer(reinterpret_cast<__gm__ InDtype *>(kHat));
            gmQRstd.SetGlobalBuffer(reinterpret_cast<__gm__ float *>(qRstd));
            gmKRstd.SetGlobalBuffer(reinterpret_cast<__gm__ float *>(kRstd));
        } else {
            // Stage6 reloads k̂; without in-kernel L2Norm that is the k input.
            gmKHat.SetGlobalBuffer(reinterpret_cast<__gm__ InDtype *>(k));
        }
        hasBetaOut = 0;
        if (betaEff != nullptr) {
            gmBetaEff.SetGlobalBuffer(reinterpret_cast<__gm__ float *>(betaEff));
            hasBetaOut = 1;
        }
    }

    // Explicit on-chip map. Offsets match design Stage 0-3.
    __aicore__ inline void InitOnChip()
    {
        subBlock = AscendC::GetSubBlockIdx();
        if ASCEND_IS_AIV {
            // MIX 1:2: GetBlockIdx is 0,1 for cube 0's two Vectors. GetBlockNum
            // on AIV already equals the cube count (same as AIC, 28 here). The
            // runtime PRINTF "Block 0/56" is 2*cubes; do not divide again.
            coreIdx = AscendC::GetBlockIdx() / 2;
            numCore = AscendC::GetBlockNum();
        } else {
            coreIdx = AscendC::GetBlockIdx();
            numCore = AscendC::GetBlockNum();
        }
        auxReady = 0;

        OnChipBuffer buf;

        // =====================================================================
        // UB map (KiB). Offsets are from chunk_gated_delta_rule_fwd_prepare_common.h. Live ranges overlap
        // by design: S1 input [10, 75) is released after k' is on L1, then
        // S3 reuses [10, 82).
        //
        //   [0.00,  0.50)  unused      512 B         hole before ubVcsIdx
        //   [0.50,  1.00)  ubVcsIdx      512 B  u32    VCS scatter idx {0,32}
        //   [1.00,  9.00)  ubIVcs        8 KiB  fp32   I_vcs = [I32 | I32]
        //   [9.00,  9.25)  ubGPrime[0]  256 B  fp32   g' ping, [64]
        //   [9.25,  9.50)  ubBetaEff[0] 256 B  fp32   beta_eff ping, [64]
        //   [9.50,  9.75)  ubGPrime[1]  256 B  fp32   g' pong
        //   [9.75, 10.00)  ubBetaEff[1] 256 B  fp32   beta_eff pong
        //   [10.0, 26.00)  ubQ[0]      16 KiB  bf16   S1 q ping
        //   [26.0, 42.00)  ubK[0]      16 KiB  bf16   S1 k ping
        //   [42.0, 58.00)  ubQ[1]      16 KiB  bf16   S1 q pong
        //   [58.0, 74.00)  ubK[1]      16 KiB  bf16   S1 k pong
        //   [74.0, 74.50)  rstd pong    512 B  fp32   k/q rstd of 2nd task
        //   [75.0, 91.00)  ubQHat[0]   16 KiB  bf16   S1 q' ping
        //   [91.0, 107.0)  ubKHat[0]   16 KiB  bf16   S1 k' ping
        //   [107,  107.25) ubKRstd[0]  256 B  fp32   K rstd ping
        //   [107.25,107.50) ubQRstd[0] 256 B  fp32   Q rstd ping
        //   [108,  124.0)  ubQHat[1]   16 KiB  bf16   S1 q' pong
        //   [124,  140.0)  ubKHat[1]   16 KiB  bf16   S1 k' pong
        //   [140,  156.0)  ubKkt[0]    16 KiB  fp32   Cube kkt ping ND (Fixpipe NZ2ND)
        //   [156,  172.0)  ubKkt[1]    16 KiB  fp32   Cube kkt pong ND
        // S7 Fixpipe output, retained until the owning AIV drains the pack:
        //   [172, 188) ubS7W[0]  [188, 204) ubS7W[1]
        //   [204, 220) ubS7U[0]  [220, 236) ubS7U[1]
        //   [236, 248) unused 12 KiB
        // S0 only, before g' is stored:
        //   [9, 25) unused (was NZ I)   [25, 41) ubS0Zero
        // S3 (after S1 q/k released). Ping/pong for the two tasks on one AIV:
        //   ping db=0: [10, 18) LPacked  [18, 34) ResVcs  [34, 50) LFull
        //   pong db=1: [50, 58) LPacked  [58, 74) ResVcs  [74, 90) LFull
        // S6 (after S3; overlaps S1/S3, g'/β at [9,10) stay):
        //   [32, 48) ubS6K[0] 16 KiB k' ping   [48, 64) ubS6K[1] k' pong
        //   V=128: [64, 80) / [80, 96) 16 KiB. V=256: [64, 96) / [96, 128) 32 KiB.
        //   vb/kbg ND → L1 NZ C0=16 via DataCopy (64,1,srcGap,0)
        // GVA (G=2/3/4) reuses ubKkt ping/pong and the owner's L1 k' slot;
        // no extra UB/L1 buffers. With the supported V=128, peak UB usage
        // ends at 236 KiB; L1 uses
        // 496 KiB of 512 KiB.
        // =====================================================================

        // UB[0.50, 1.00) KiB = 512 B, uint32. Only the first 8 values are used.
        // VCS scatter index for packing two 32x32 leaves into I_vcs 32x64:
        // values are {0, 32} (left leaf at col 0, right leaf at col 32).
        ubVcsIdx = buf.template GetBuffer<BufferType::ASCEND_UB, uint32_t>(kUbVcsIdx);

        // UB[1.00, 9.00) KiB = 8 KiB, fp32 ND [32, 64].
        // I_vcs = concat along K of two I_32 identity leaves. Prefetched to
        // ubResVcs before WaitCubeKktDone; VCS then overwrites with (I+Lii)^{-1}.
        ubIVcs = buf.template GetBuffer<BufferType::ASCEND_UB, float>(kUbIVcs);

        // UB[9.00, 25.00) KiB unused (old Cube NZ I). Overlaps g'/beta.

        // UB[25.00, 41.00) KiB = 16 KiB, fp32.
        // Stage0 ND I then zeros for leaf L1. Released before S1.
        ubS0Zero = buf.template GetBuffer<BufferType::ASCEND_UB, float>(kUbS0Zero);

        // UB[9.00, 10.00) resident g'/beta, then S1 q/k and S2 kkt ping/pong.
        // db=0: AIV0 task 0 / AIV1 task 1; db=1: AIV0 task 2 / AIV1 task 3.
        for (int32_t db = 0; db < 2; ++db) {
            ubGPrime[db] = buf.template GetBuffer<BufferType::ASCEND_UB, float>(kUbGPrime[db]);
            ubBetaEff[db] = buf.template GetBuffer<BufferType::ASCEND_UB, float>(kUbBetaEff[db]);
            ubQ[db] = buf.template GetBuffer<BufferType::ASCEND_UB, InDtype>(kUbS1Q[db]);
            ubK[db] = buf.template GetBuffer<BufferType::ASCEND_UB, InDtype>(kUbS1K[db]);
            ubKkt[db] = buf.template GetBuffer<BufferType::ASCEND_UB, float>(kUbS2Kkt[db]);
            ubS6K[db] = buf.template GetBuffer<BufferType::ASCEND_UB, InDtype>(kUbS6K[db]);
            const uint32_t vOff = (V > 128 && db == 1) ? kUbS6VPong256 : kUbS6V[db];
            ubS6V[db] = buf.template GetBuffer<BufferType::ASCEND_UB, InDtype>(vOff);
            ubS6K[db].SetSize(static_cast<uint32_t>(kChunk64 * K));
            ubS6V[db].SetSize(static_cast<uint32_t>(kChunk64 * V));
            ubQHat[db] = buf.template GetBuffer<BufferType::ASCEND_UB, InDtype>(kUbS1QHat[db]);
            ubKHat[db] = buf.template GetBuffer<BufferType::ASCEND_UB, InDtype>(kUbS1KHat[db]);
            ubKRstd[db] = buf.template GetBuffer<BufferType::ASCEND_UB, float>(kUbS1KRstd[db]);
            ubQRstd[db] = buf.template GetBuffer<BufferType::ASCEND_UB, float>(kUbS1QRstd[db]);
        }

        for (int32_t db = 0; db < 2; ++db) {
            ubS7W[db] = buf.template GetBuffer<BufferType::ASCEND_UB, InDtype>(kUbS7W[db]);
            ubS7U[db] = buf.template GetBuffer<BufferType::ASCEND_UB, InDtype>(kUbS7U[db]);
            ubS7W[db].SetSize(static_cast<uint32_t>(kChunk64 * K));
            ubS7U[db].SetSize(static_cast<uint32_t>(kChunk64 * V));
        }

        // UB[10, 90) Stage3 ping/pong. Overlaps S1 q/k; valid after k' is on L1.
        for (int32_t db = 0; db < 2; ++db) {
            ubLPacked[db] = buf.template GetBuffer<BufferType::ASCEND_UB, float>(kUbS3LPacked[db]);
            ubResVcs[db] = buf.template GetBuffer<BufferType::ASCEND_UB, float>(kUbS3ResVcs[db]);
            ubLFull[db] = buf.template GetBuffer<BufferType::ASCEND_UB, float>(kUbS3LFull[db]);
        }

        // AIV UB HardEvent ids: kHeUb0, kHeUb1, kHeS3Pack (common.h).
        // Cube even/odd stays numeric bank = t&1 (FIX_M / M_MTE1 / FIX_MTE2).

        // L1 512 KiB. Four task slots (taskIdx 0..3).
        for (uint32_t t = 0; t < static_cast<uint32_t>(kTasksPerRound); ++t) {
            l1KHat[t] = buf.template GetBuffer<BufferType::ASCEND_CB, InDtype>(L1KHat(t));
            l1NegL[t] = buf.template GetBuffer<BufferType::ASCEND_CB, float>(L1NegL(t));
            l1LeafRight[t] = buf.template GetBuffer<BufferType::ASCEND_CB, float>(L1LeafRight(t));
            l1LeafLeft[t] = buf.template GetBuffer<BufferType::ASCEND_CB, float>(L1LeafLeft(t));
            l1A[t] = buf.template GetBuffer<BufferType::ASCEND_CB, InDtype>(L1ResidentA(t));
            l1Kbg[t] = buf.template GetBuffer<BufferType::ASCEND_CB, InDtype>(L1ResidentKbg(t));
            l1Vb[t] = buf.template GetBuffer<BufferType::ASCEND_CB, InDtype>(L1ResidentVb(t));
            l1Vb[t].SetSize(static_cast<uint32_t>(kChunk64 * V));
            l1Kbg[t].SetSize(static_cast<uint32_t>(kChunk64 * K));
            l1Vb1[t] = buf.template GetBuffer<BufferType::ASCEND_CB, InDtype>(L1ResidentVb(t) + kBytesK128);
            l1Vb1[t].SetSize(static_cast<uint32_t>(kChunk64 * kGdnHeadDimK));
            // Y at [0,64). k' aliases NegL at [64,128); Stage3 overwrites
            // k' after Stage2.
            l1Y[t] = buf.template GetBuffer<BufferType::ASCEND_CB, float>(L1Y(t));
        }

        // L1[480, 496) KiB = 16 KiB, fp32 cube-NZ I_64, C0=8.
        l1I = buf.template GetBuffer<BufferType::ASCEND_CB, float>(kL1ResidentI);

        // L0A/L0B 64 KiB, L0C 256 KiB. bf16 and fp32 views alias the same banks.
        // [0]=even [0,16)/[32,48)/L0C[0,64); [1]=odd [16,32)/[48,64)/L0C[64,128).
        // Stage2 kkt uses pair 0/1. Stage4 Acc and Stage5 second MMAD share
        // Stage7's P slots; Stage4/5 drain before Stage7. SetSize(16 KiB) so
        // ping does not keep the remaining 32 KiB and overlap pong.
        for (uint32_t b = 0; b < 2; ++b) {
            l0A[b] = buf.template GetBuffer<BufferType::ASCEND_L0A, InDtype>(kL0PairOff[b]);
            l0B[b] = buf.template GetBuffer<BufferType::ASCEND_L0B, InDtype>(kL0PairOff[b]);
            l0Af[b] = buf.template GetBuffer<BufferType::ASCEND_L0A, float>(kL0PairOff[b]);
            l0Bf[b] = buf.template GetBuffer<BufferType::ASCEND_L0B, float>(kL0PairOff[b]);
            l0AfP[b] = buf.template GetBuffer<BufferType::ASCEND_L0A, float>(kL0S7Off[b]);
            l0BfP[b] = buf.template GetBuffer<BufferType::ASCEND_L0B, float>(kL0S7Off[b]);
            l0AS7[b] = buf.template GetBuffer<BufferType::ASCEND_L0A, InDtype>(kL0S7Off[b]);
            l0BS7[b] = buf.template GetBuffer<BufferType::ASCEND_L0B, InDtype>(kL0S7Off[b]);
            l0AS7[b].SetSize(kL0S7Slot / sizeof(InDtype));
            l0BS7[b].SetSize(kL0S7Slot / sizeof(InDtype));
            l0CS7[b] = buf.template GetBuffer<BufferType::ASCEND_L0C, float>(kL0CS7Off[b]);
            l0CS7[b].SetSize(static_cast<uint32_t>(kChunk64 * 128));
        }

        // L0C 256 KiB: four 64 KiB-aligned slots, one 16 KiB C tile each.
        // Stage2 kkt still uses slots 0/1 (even/odd). Stage4 I@I writes all
        // nThis slots before Wait Stage3; LeafLeft@NegL accumulates in place.
        for (uint32_t t = 0; t < static_cast<uint32_t>(kTasksPerRound); ++t) {
            l0CTask[t] = buf.template GetBuffer<BufferType::ASCEND_L0C, float>(t * kL0CTaskStride);
            l0CTask[t].SetSize(kL0CTaskStride / sizeof(float));
        }
    }

    // ========================= Stage 0 =========================
    // Once per AIV: I_vcs + scatter idx, zero L1
    // leaf slots for this AIV's tasks, AIV0 paints Cube I_64 ND→NZ C0=8.
    __aicore__ inline void Stage0_GenerateResidentAux()
    {
        if (auxReady != 0) {
            return;
        }
        FillVcsIdentity(ubIVcs, ubVcsIdx);
        // Leaf zeros first so both AIVs copy in parallel. ubS0Zero is then
        // free for AIV0 to paint I. AIV1 can leave for Stage1 while AIV0
        // uploads I. L1 leaf slots are disjoint by taskIdx (AIV0: 0,2;
        // AIV1: 1,3). Scatter only rewrites the 32x32 quadrant; TR/BL stay
        // zero if primed once.
        Duplicate(ubS0Zero, 0.0f, static_cast<int32_t>(kChunk64 * kChunk64));
        SetFlag<HardEvent::V_MTE3>(kHeUb0);
        WaitFlag<HardEvent::V_MTE3>(kHeUb0);
        for (uint32_t t = static_cast<uint32_t>(subBlock); t < static_cast<uint32_t>(kTasksPerRound); t += 2) {
            UbToL1Fp32(l1LeafLeft[t], ubS0Zero, kChunk64);
            UbToL1Fp32(l1LeafRight[t], ubS0Zero, kChunk64);
        }
        SetFlag<HardEvent::MTE3_V>(kHeUb0);
        WaitFlag<HardEvent::MTE3_V>(kHeUb0);
        // Cube I_64 is shared L1: only AIV0 paints ND I and 8-col uploads.
        if (subBlock == 0) {
            Identity64VF(ubS0Zero);
            SetFlag<HardEvent::V_MTE3>(kHeUb0);
            WaitFlag<HardEvent::V_MTE3>(kHeUb0);
            UbNd64ToL1Nz8(l1I, ubS0Zero);
            SetFlag<HardEvent::MTE3_V>(kHeUb0);
            WaitFlag<HardEvent::MTE3_V>(kHeUb0);
        }
        auxReady = 1;
    }

    // ========================= Stage 1 =========================
    // Per-task g' (cumsum) and β_eff. Owner HK: L2Norm k then q when
    // useQkL2norm, else k as-is (no q load). Store hat/rstd only on the
    // L2Norm path. k' ND→L1 NZ C0=16, NotifyAicStage1Done so Cube kkt can
    // overlap Q/gate. k' aliases NegL: Wait pack N Stage4 before the L1
    // write so Stage1 can overlap pack N Stage5/7 (V3 G=1 schedule).
    // Sibling HV skip K/Q and still wait Stage4 to consume the flag.
    // Tail (M<BT) zero-fills this tile before copy-in; aligned tiles skip
    // Duplicate. Event order is Pad → k' L1 (Wait Stage4) → Notify → q/gate.
    __aicore__ inline void Stage1_PadTailIfNeeded(const ChunkRange &chunk, int64_t hv, int64_t taskIdx)
    {
        const int32_t db = PingPongSlot(taskIdx);
        const int32_t nValid = static_cast<int32_t>(chunk.M);
        const int32_t nPad = static_cast<int32_t>(chunkSize);
        if (nValid >= nPad) {
            return;
        }
        if (OwnsHk(hv)) {
            Duplicate(ubK[db], static_cast<InDtype>(0), nPad * static_cast<int32_t>(K));
            if (useQkL2norm != 0) {
                Duplicate(ubKHat[db], static_cast<InDtype>(0), nPad * static_cast<int32_t>(K));
                Duplicate(ubQ[db], static_cast<InDtype>(0), nPad * static_cast<int32_t>(K));
                Duplicate(ubQHat[db], static_cast<InDtype>(0), nPad * static_cast<int32_t>(K));
            }
        }
        Duplicate(ubGPrime[db], 0.0f, nPad);
        Duplicate(ubBetaEff[db], 0.0f, nPad);
        SetFlag<HardEvent::V_MTE2>(kHeUb1);
        WaitFlag<HardEvent::V_MTE2>(kHeUb1);
    }

    __aicore__ inline void Stage1_UploadK(const ChunkRange &chunk, int64_t hv, int64_t taskIdx)
    {
        if (!OwnsHk(hv)) {
            WaitAicStage4Done(taskIdx);
            return;
        }
        const int64_t hk = hv / HRatio;
        const int32_t db = PingPongSlot(taskIdx);
        const int32_t nElem = static_cast<int32_t>(chunk.M * K);
        const int32_t nValid = static_cast<int32_t>(chunk.M);
        const int64_t offQk = OffsetBHTD(chunk.batch, hk, chunk.tokenStart, HK, T, K);
        const int64_t offRstd = OffsetBHT(chunk.batch, hk, chunk.tokenStart, HK, T);
        LocalTensor<InDtype> l1K = l1KHat[static_cast<uint32_t>(taskIdx)];

        DataCopy(ubK[db], gmK[offQk], nElem);
        SetFlag<HardEvent::MTE2_V>(kHeUb0);
        WaitFlag<HardEvent::MTE2_V>(kHeUb0);
        if (useQkL2norm != 0) {
            L2NormK128VF<InDtype>(ubK[db], ubKHat[db], ubKRstd[db], static_cast<uint32_t>(nValid), kGdnL2NormEps);
            SetFlag<HardEvent::V_MTE3>(kHeUb0);
            WaitFlag<HardEvent::V_MTE3>(kHeUb0);
            WaitAicStage4Done(taskIdx);
            UploadBf16NdToL1(l1K, ubKHat[db], static_cast<uint32_t>(K));
            NotifyAicStage1Done(taskIdx);
            DataCopy(gmKHat[offQk], ubKHat[db], nElem);
            CopyUbToGmElems(gmKRstd[offRstd], ubKRstd[db], static_cast<uint32_t>(nValid));

            DataCopy(ubQ[db], gmQ[offQk], nElem);
            SetFlag<HardEvent::MTE2_V>(kHeUb0);
            WaitFlag<HardEvent::MTE2_V>(kHeUb0);
            L2NormK128VF<InDtype>(ubQ[db], ubQHat[db], ubQRstd[db], static_cast<uint32_t>(nValid), kGdnL2NormEps);
            SetFlag<HardEvent::V_MTE3>(kHeUb0);
            WaitFlag<HardEvent::V_MTE3>(kHeUb0);
            DataCopy(gmQHat[offQk], ubQHat[db], nElem);
            CopyUbToGmElems(gmQRstd[offRstd], ubQRstd[db], static_cast<uint32_t>(nValid));
        } else {
            SetFlag<HardEvent::MTE2_MTE3>(kHeUb0);
            WaitFlag<HardEvent::MTE2_MTE3>(kHeUb0);
            WaitAicStage4Done(taskIdx);
            UploadBf16NdToL1(l1K, ubK[db], static_cast<uint32_t>(K));
            NotifyAicStage1Done(taskIdx);
        }
    }

    __aicore__ inline void Stage1_GateAndBeta(const ChunkRange &chunk, int64_t hv, int64_t taskIdx)
    {
        const int32_t db = PingPongSlot(taskIdx);
        const int32_t nValid = static_cast<int32_t>(chunk.M);
        const int64_t offG = OffsetBHT(chunk.batch, hv, chunk.tokenStart, HV, T);
        LocalTensor<float> ubGfp = ubGPrime[db];
        LocalTensor<float> ubBfp = ubBetaEff[db];
        LocalTensor<GateDtype> ubGRaw = ubGfp.template ReinterpretCast<GateDtype>();
        LocalTensor<GateDtype> ubBRaw = ubBfp.template ReinterpretCast<GateDtype>();

        // g / beta share the resident 256 B slots. GateDtype view of the same
        // address: fp32 copy is identity; b16/fp16 fills the first 128 B, then
        // one VL LoadCast stores 64 fp32. n<=64, load-then-store, no ubQHat.
        CopyGmToUbElems(ubGRaw, gmG[offG], static_cast<uint32_t>(nValid));
        CopyGmToUbElems(ubBRaw, gmBeta[offG], static_cast<uint32_t>(nValid));
        SetFlag<HardEvent::MTE2_V>(kHeUb0);
        WaitFlag<HardEvent::MTE2_V>(kHeUb0);

        if (useGateInKernel != 0) {
            float aLog = ScalarToFp32(gmALog.GetValue(hv));
            float dt = (hasDtBias != 0) ? ScalarToFp32(gmDt.GetValue(hv)) : 0.0f;
            SetFlag<HardEvent::S_V>(kHeUb0);
            WaitFlag<HardEvent::S_V>(kHeUb0);
            GateSoftplusVF<GateDtype>(ubGRaw, ubGfp, aLog, dt, static_cast<uint32_t>(nValid));
        } else if constexpr (!IsSameType<GateDtype, float>::value) {
            CastToFp32VF<GateDtype>(ubGRaw, ubGfp, static_cast<uint32_t>(nValid));
        }
        float scale = (useExp2 != 0) ? kGdnRcpLn2 : 1.0f;
        CumsumScaleVF(ubGfp, scale, static_cast<uint32_t>(nValid));
        SetFlag<HardEvent::V_MTE3>(kHeUb0);
        WaitFlag<HardEvent::V_MTE3>(kHeUb0);
        CopyUbToGmElems(gmGOut[offG], ubGfp, static_cast<uint32_t>(nValid));

        if (useBetaSigmoid != 0) {
            float bscale = (allowNegEigval != 0) ? 2.0f : 1.0f;
            BetaSigmoidVF<GateDtype>(ubBRaw, ubBfp, bscale, static_cast<uint32_t>(nValid));
        } else if constexpr (!IsSameType<GateDtype, float>::value) {
            CastToFp32VF<GateDtype>(ubBRaw, ubBfp, static_cast<uint32_t>(nValid));
        }

        if (hasBetaOut != 0) {
            SetFlag<HardEvent::V_MTE3>(kHeUb0);
            WaitFlag<HardEvent::V_MTE3>(kHeUb0);
            CopyUbToGmElems(gmBetaEff[offG], ubBfp, static_cast<uint32_t>(nValid));
        }
    }

    __aicore__ inline void Stage1_OneTask(const ChunkRange &chunk, int64_t hv, int64_t taskIdx)
    {
        const int32_t db = PingPongSlot(taskIdx);
        if (db == 0) {
            SetFlag<HardEvent::MTE3_MTE2>(kHeUb0);
            WaitFlag<HardEvent::MTE3_MTE2>(kHeUb0);
        }
        Stage1_PadTailIfNeeded(chunk, hv, taskIdx);
        Stage1_UploadK(chunk, hv, taskIdx);
        Stage1_GateAndBeta(chunk, hv, taskIdx);
    }

    // Stage2 helper: dualDstCtl splits M or N across the two AIVs; it does
    // not broadcast. G>1 needs the full 64x64 kkt on both Vectors, so two
    // Fixpipes.
    __aicore__ inline void DumpKktToUb(LocalTensor<float> l0c, int32_t db, uint8_t subBlk, uint8_t bank,
                                       bool shareBothAiv)
    {
        const uint32_t n = static_cast<uint32_t>(chunkSize);
        if (!shareBothAiv) {
            FixpipeL0cToUbFp32Nd(ubKkt[db], l0c, n, subBlk);
            return;
        }
        FixpipeL0cToUbFp32Nd(ubKkt[db], l0c, n, 0);
        SetFlag<HardEvent::FIX_MTE2>(bank);
        WaitFlag<HardEvent::FIX_MTE2>(bank);
        FixpipeL0cToUbFp32Nd(ubKkt[db], l0c, n, 1);
    }

    // After one Cube kkt, wake every HV in this pack that shares the same
    // (chunk, hk). G=1 notifies only the owner.
    __aicore__ inline void NotifyKktSiblings(int64_t base, int64_t nThis, int64_t ownerTask)
    {
        const int64_t ownerWork = PackWorkId(base, nThis, ownerTask);
        const int64_t ownerChunk = ownerWork / HV;
        const int64_t ownerHv = ownerWork % HV;
        const int64_t hvLo = ownerHv - ((HRatio <= 1) ? 0 : (ownerHv % HRatio));
        const int64_t hvHi = hvLo + ((HRatio <= 1) ? 1 : HRatio);
        for (int64_t t2 = 0; t2 < nThis; ++t2) {
            const int64_t work2 = PackWorkId(base, nThis, t2);
            if ((work2 / HV) != ownerChunk) {
                continue;
            }
            const int64_t hv2 = work2 % HV;
            if (hv2 >= hvLo && hv2 < hvHi) {
                NotifyAivKktDone(t2);
            }
        }
    }


    // ========================= Stage 2 =========================
    // Cube kkt = k' @ k'^T, once per HK after WaitAivStage1Done. Even tasks
    // use L0[0,16)/L0C[0,64); odd use L0[16,32)/L0C[64,128). Wait M_MTE1
    // (primed in ProcessAic). Inner Matmul Wait FIX_M matches V3. A full
    // G=2 pack keeps each KKT on its owning AIV; G=3/4 and a partial G=2
    // pack dump it to both AIVs. G=1 notifies here; G>1 siblings are
    // notified from ProcessAic.
    __aicore__ inline void Stage2_AicOne(int64_t taskIdx, int64_t nThis)
    {
        const int32_t bt = static_cast<int32_t>(chunkSize);
        const int32_t kk = static_cast<int32_t>(K);
        const uint8_t bank = static_cast<uint8_t>(taskIdx & 1);
        const int32_t db = PingPongSlot(taskIdx);
        const bool shareBothAiv = (HRatio > 2) || (HRatio == 2 && nThis < kTasksPerRound);
        WaitFlag<HardEvent::M_MTE1>(bank);
        MatmulToL0C<InDtype>(l1KHat[taskIdx], l1KHat[taskIdx], l0A[bank], l0B[bank], l0CTask[bank], bt, bt, kk, true,
                             false, false, bank);
        SetFlag<HardEvent::M_FIX>(bank);
        SetFlag<HardEvent::M_MTE1>(bank);
        WaitFlag<HardEvent::M_FIX>(bank);
        DumpKktToUb(l0CTask[bank], db, bank, bank, shareBothAiv);
        SetFlag<HardEvent::FIX_M>(bank);
        if (HRatio <= 1) {
            NotifyAivKktDone(taskIdx);
        }
    }

    // ========================= Stage 3 =========================
    // Gate (no kkt) plus I_vcs → ubResVcs, both before WaitCubeKktDone so Exp
    // and the MTE3 copy overlap Cube kkt. I dst is ubResVcs, not ubLFull.
    // After kkt: L = kkt ⊙ G, pack leaves (must see -L), -L UB→L1, VCS on V.
    __aicore__ inline void Stage3_PrepareGate(int64_t taskIdx)
    {
        const int32_t db = PingPongSlot(taskIdx);
        if (useExp2 != 0) {
            GateLowerLVF<true>(ubGPrime[db], ubBetaEff[db], ubLFull[db]);
        } else {
            GateLowerLVF<false>(ubGPrime[db], ubBetaEff[db], ubLFull[db]);
        }
        DataCopy(ubResVcs[db], ubIVcs, static_cast<int32_t>(kVcsPackedElems32));
    }

    __aicore__ inline void Stage3_AivOne(int64_t hv, int64_t taskIdx)
    {
        WaitCubeKktDone(taskIdx);
        const int32_t db = PingPongSlot(taskIdx);
        const int32_t kktDb = PingPongSlot(OwnerTaskIdx(hv, taskIdx));
        MulKktGateVF(ubKkt[kktDb], ubLFull[db]);
        SetFlag<HardEvent::V_MTE3>(kHeUb0);
        WaitFlag<HardEvent::V_MTE3>(kHeUb0);
        PackDiagLeavesFromUb(ubLPacked[db], ubLFull[db]);
        SetFlag<HardEvent::MTE3_V>(kHeS3Pack);
        WaitFlag<HardEvent::MTE3_V>(kHeS3Pack);
        UbNd64ToL1Nz8(l1NegL[taskIdx], ubLFull[db]);
        MulReduceScatterVF32(ubResVcs[db], ubLPacked[db], ubResVcs[db], ubVcsIdx);
        SetFlag<HardEvent::V_MTE3>(kHeUb0);
        WaitFlag<HardEvent::V_MTE3>(kHeUb0);
        UploadDiagLeavesToL1(l1LeafRight[taskIdx], l1LeafLeft[taskIdx], ubResVcs[db]);
        NotifyAicStage3Done(taskIdx);
    }

    // ========================= Stage 4 =========================
    // Y = I + LeafLeft @ (-L). Prefill loads resident I once and MMADs I@I
    // into each task's L0C slot before Wait Stage3 (hidden under Vector).
    // Event bank=t&1; Wait M_FIX after each I@I so Acc Wait FIX_M(bank)
    // is that slot's Cube-idle credit, not ProcessAic's init FIX_M(1).
    // Acc uses P L0 banks (ping keeps I). Dump(t-1) overlaps Acc(t);
    // each task Fixpipes into its own gmWsY slot.
    __aicore__ inline void Stage4_PrefillI(int64_t nThis)
    {
        const int32_t bt = static_cast<int32_t>(chunkSize);
        if (nThis <= 0) {
            return;
        }
        WaitFlag<HardEvent::M_MTE1>(0);
        LoadL1NzToL0AB<float>(l1I, l1I, l0Af[0], l0Bf[0], bt, bt, bt, true, false, 0);
        for (int64_t t = 0; t < nThis; ++t) {
            const uint8_t bank = static_cast<uint8_t>(t & 1);
            MmadL0ABToL0C<float>(l0Af[0], l0Bf[0], l0CTask[t], bt, bt, bt, true, bank);
            SetFlag<HardEvent::M_FIX>(bank);
            WaitFlag<HardEvent::M_FIX>(bank);
            SetFlag<HardEvent::FIX_M>(bank);
        }
        SetFlag<HardEvent::M_MTE1>(0);
    }

    __aicore__ inline void Stage4_AccIssue(int64_t taskIdx)
    {
        const int32_t bt = static_cast<int32_t>(chunkSize);
        const uint8_t bank = static_cast<uint8_t>(taskIdx & 1);
        WaitFlag<HardEvent::M_MTE1>(bank);
        MatmulToL0C<float>(l1LeafLeft[taskIdx], l1NegL[taskIdx], l0AfP[bank], l0BfP[bank], l0CTask[taskIdx], bt, bt, bt,
                           false, true, true, bank);
        SetFlag<HardEvent::M_FIX>(bank);
        SetFlag<HardEvent::M_MTE1>(bank);
    }

    __aicore__ inline void Stage4_Dump(int64_t taskIdx)
    {
        const uint8_t bank = static_cast<uint8_t>(taskIdx & 1);
        WaitFlag<HardEvent::M_FIX>(bank);
        FixpipeL0cToGmNzCs(gmWsY[WsYOffset(taskIdx)], l0CTask[taskIdx], kChunk64);
        SetFlag<HardEvent::FIX_M>(bank);
        SetFlag<HardEvent::FIX_MTE2>(bank);
        WaitFlag<HardEvent::FIX_MTE2>(bank);
        CopyGmNzToL1Fp32(l1Y[taskIdx], gmWsY[WsYOffset(taskIdx)], kChunk64);
        NotifyAivStage4Done(taskIdx);
        SetFlag<HardEvent::MTE2_MTE1>(taskIdx);
    }

    // ========================= Stage 5 =========================
    // A = LeafLeft + Y @ LeafRight. tmp = I @ LeafLeft (init) then
    // Y @ LeafRight accumulate. Intra-task second Load uses L0 [32,48)/[48,64)
    // so MTE1 overlaps the first Cube M. Dump stays per-task after both MMADs.
    // Full chunk + outputA: L0C→gmA (valid M rows) then Nd2Nz back to L1.
    // Tail or outputA=0: L0C→L1 NZ directly (padding rows stay in L0C).
    __aicore__ inline void Stage5_Compute(int64_t taskIdx)
    {
        const int32_t bt = static_cast<int32_t>(chunkSize);
        const uint8_t bank = static_cast<uint8_t>(taskIdx & 1);
        WaitFlag<HardEvent::M_MTE1>(bank);
        MatmulToL0C<float>(l1I, l1LeafLeft[taskIdx], l0Af[bank], l0Bf[bank], l0CTask[taskIdx], bt, bt, bt, true, false,
                           false, bank);
        SetFlag<HardEvent::FIX_M>(bank);
        MatmulToL0C<float>(l1Y[taskIdx], l1LeafRight[taskIdx], l0AfP[bank], l0BfP[bank], l0CTask[taskIdx], bt, bt, bt,
                           false, false, false, bank);
        SetFlag<HardEvent::M_FIX>(bank);
        SetFlag<HardEvent::M_MTE1>(bank);
    }

    __aicore__ inline void DumpAL0cToL1(int64_t taskIdx, uint32_t n)
    {
        FixpipeParamsArch3510<CO2Layout::NZ> aFixpipeParams;
        aFixpipeParams.nSize = n;
        aFixpipeParams.mSize = n;
        aFixpipeParams.srcStride = n;
        aFixpipeParams.dstStride = n * 16;
        aFixpipeParams.quantPre = QuantMode_t::F322BF16;
        aFixpipeParams.unitFlag = 0;
        aFixpipeParams.isChannelSplit = false;
        Fixpipe<InDtype, float, CFG_NZ_L1>(l1A[taskIdx], l0CTask[taskIdx], aFixpipeParams);
    }

    __aicore__ inline void Stage5_Dump(const ChunkRange &chunk, int64_t hv, int64_t taskIdx)
    {
        const uint8_t bank = static_cast<uint8_t>(taskIdx & 1);
        const uint32_t n = static_cast<uint32_t>(chunkSize);
        const uint32_t m = static_cast<uint32_t>(chunk.M);
        const int64_t offA = OffsetBHTD(chunk.batch, hv, chunk.tokenStart, HV, T, chunkSize);
        WaitFlag<HardEvent::M_FIX>(bank);
        if (outputA != 0) {
            FixpipeL0cToGmNd<InDtype>(gmA[offA], l0CTask[taskIdx], m, n, n);
            SetFlag<HardEvent::FIX_MTE2>(bank);
            WaitFlag<HardEvent::FIX_MTE2>(bank);
            if (m == n) {
                CopyGmNdToL1Nz<InDtype>(l1A[taskIdx], gmA[offA], n, n);
                SetFlag<HardEvent::MTE2_MTE1>(taskIdx);
            } else {
                DumpAL0cToL1(taskIdx, n);
                SetFlag<HardEvent::FIX_MTE1>(taskIdx);
            }
        } else {
            DumpAL0cToL1(taskIdx, n);
            SetFlag<HardEvent::FIX_MTE1>(taskIdx);
        }
        SetFlag<HardEvent::FIX_M>(bank);
    }

    // ========================= Stage 6 =========================
    // vb = v * β, kbg = k' * β * exp2(g'). ND→L1 NZ C0=16. V3 runs this
    // after Stage3 (no Stage5 wait) so it overlaps Cube Stage4/5.
    // Tail zero-fills UB then copies M rows.
    __aicore__ inline void Stage6_AivOne(const ChunkRange &chunk, int64_t hv, int64_t taskIdx)
    {
        const int64_t hk = hv / HRatio;
        const int64_t offK = OffsetBHTD(chunk.batch, hk, chunk.tokenStart, HK, T, K);
        const int64_t offV = OffsetBHTD(chunk.batch, hv, chunk.tokenStart, HV, T, V);
        const int32_t nValid = static_cast<int32_t>(chunk.M);
        const int32_t nPad = static_cast<int32_t>(chunkSize);
        const int32_t nK = nValid * static_cast<int32_t>(K);
        const int32_t nV = nValid * static_cast<int32_t>(V);
        const int32_t db = PingPongSlot(taskIdx);
        LocalTensor<InDtype> ubKnd = ubS6K[db];
        LocalTensor<InDtype> ubVnd = ubS6V[db];
        LocalTensor<float> beta = ubBetaEff[db];
        LocalTensor<float> g = ubGPrime[db];
        if (nValid < nPad) {
            SetFlag<HardEvent::MTE3_V>(kHeUb0);
            WaitFlag<HardEvent::MTE3_V>(kHeUb0);
            Duplicate(ubVnd, static_cast<InDtype>(0), nPad * static_cast<int32_t>(V));
            Duplicate(ubKnd, static_cast<InDtype>(0), nPad * static_cast<int32_t>(K));
            SetFlag<HardEvent::V_MTE2>(kHeUb0);
            WaitFlag<HardEvent::V_MTE2>(kHeUb0);
        }
        DataCopy(ubVnd, gmV[offV], nV);
        SetFlag<HardEvent::MTE2_V>(kHeUb0);
        WaitFlag<HardEvent::MTE2_V>(kHeUb0);
        ScaleRowsVF<InDtype>(ubVnd, ubVnd, beta, static_cast<uint32_t>(chunkSize), static_cast<uint32_t>(V));
        SetFlag<HardEvent::V_MTE3>(kHeUb0);
        WaitFlag<HardEvent::V_MTE3>(kHeUb0);
        UploadBf16NdToL1(l1Vb[taskIdx], ubVnd, static_cast<uint32_t>(V));

        DataCopy(ubKnd, gmKHat[offK], nK);
        SetFlag<HardEvent::MTE2_V>(kHeUb1);
        WaitFlag<HardEvent::MTE2_V>(kHeUb1);
        if (useExp2 != 0) {
            ScaleRowsBetaExp2gVF<InDtype, true>(ubKnd, ubKnd, beta, g, static_cast<uint32_t>(chunkSize));
        } else {
            ScaleRowsBetaExp2gVF<InDtype, false>(ubKnd, ubKnd, beta, g, static_cast<uint32_t>(chunkSize));
        }
        SetFlag<HardEvent::V_MTE3>(kHeUb1);
        WaitFlag<HardEvent::V_MTE3>(kHeUb1);
        UploadBf16NdToL1(l1Kbg[taskIdx], ubKnd, static_cast<uint32_t>(K));
    }

    // ========================= Stage 7 =========================
    // W = A @ kbg (L0 ping), U = A @ vb (L0 pong). Fixpipe retains both
    // results in the owning AIV's UB; the next pack drains them to GM.
    __aicore__ inline void Stage7_AicOne(const ChunkRange &chunk, int64_t hv, int64_t taskIdx)
    {
        const uint32_t rows = static_cast<uint32_t>(chunk.M);
        const uint32_t nK = static_cast<uint32_t>(K);
        const uint32_t nV = static_cast<uint32_t>(V);
        const int32_t bt = static_cast<int32_t>(chunkSize);
        const int32_t db = PingPongSlot(taskIdx);
        FixpipeParamsArch3510<CO2Layout::ROW_MAJOR> wuFixpipeParams;
        wuFixpipeParams.nSize = nK;
        wuFixpipeParams.mSize = rows;
        wuFixpipeParams.srcStride = kChunk64;
        wuFixpipeParams.dstStride = nK;
        wuFixpipeParams.quantPre = QuantMode_t::F322BF16;
        wuFixpipeParams.dualDstCtl = 0;
        wuFixpipeParams.subBlockId = static_cast<uint8_t>(taskIdx & 1);
        wuFixpipeParams.isChannelSplit = false;
        wuFixpipeParams.params.ndNum = 1;
        wuFixpipeParams.params.srcNdStride = 0;
        wuFixpipeParams.params.dstNdStride = 0;
        WaitFlag<HardEvent::M_MTE1>(0);
        WuMatmulToL0C<InDtype>(l1A[taskIdx], l1Kbg[taskIdx], l0AS7[0], l0BS7[0], l0CS7[0], bt, static_cast<int32_t>(nK),
                               bt, 0);
        SetFlag<HardEvent::M_FIX>(0);
        WaitFlag<HardEvent::M_FIX>(0);
        Fixpipe<InDtype, float, CFG_ROW_MAJOR_UB>(ubS7W[db], l0CS7[0], wuFixpipeParams);
        SetFlag<HardEvent::FIX_M>(0);
        SetFlag<HardEvent::M_MTE1>(0);

        wuFixpipeParams.nSize = kGdnHeadDimK;
        wuFixpipeParams.dstStride = nV;
        WaitFlag<HardEvent::M_MTE1>(1);
        WuMatmulToL0C<InDtype>(l1A[taskIdx], l1Vb[taskIdx], l0AS7[1], l0BS7[1], l0CS7[1], bt,
                               static_cast<int32_t>(kGdnHeadDimK), bt, 1);
        SetFlag<HardEvent::M_FIX>(1);
        SetFlag<HardEvent::M_MTE1>(1);
        WaitFlag<HardEvent::M_FIX>(1);
        // V=128 U is 16 KiB and stays in ubS7U until the next pack drains.
        // V=256 U is 32 KiB; UB is 248 KiB and the retain window [204, 248)
        // cannot hold two 32 KiB tiles, so both 128-col halves go to GM.
        if (nV > kGdnHeadDimK) {
            const int64_t offU = OffsetBHTD(chunk.batch, hv, chunk.tokenStart, HV, T, V);
            FixpipeL0cToGmNd<InDtype>(gmU[offU], l0CS7[1], rows, kGdnHeadDimK, nV);
            SetFlag<HardEvent::FIX_MTE2>(1);
            WaitFlag<HardEvent::FIX_MTE2>(1);
            SetFlag<HardEvent::FIX_M>(1);
            WaitFlag<HardEvent::M_MTE1>(1);
            WuMatmulToL0C<InDtype>(l1A[taskIdx], l1Vb1[taskIdx], l0AS7[1], l0BS7[1], l0CS7[1], bt,
                                   static_cast<int32_t>(kGdnHeadDimK), bt, 1);
            SetFlag<HardEvent::M_FIX>(1);
            SetFlag<HardEvent::M_MTE1>(1);
            WaitFlag<HardEvent::M_FIX>(1);
            FixpipeL0cToGmNd<InDtype>(gmU[offU + kGdnHeadDimK], l0CS7[1], rows, kGdnHeadDimK, nV);
            SetFlag<HardEvent::FIX_MTE2>(1);
            WaitFlag<HardEvent::FIX_MTE2>(1);
            SetFlag<HardEvent::FIX_M>(1);
        } else {
            Fixpipe<InDtype, float, CFG_ROW_MAJOR_UB>(ubS7U[db], l0CS7[1], wuFixpipeParams);
            SetFlag<HardEvent::FIX_M>(1);
        }
    }

    __aicore__ inline void DecodeTask(int64_t base, int64_t nThis, int64_t taskIdx, ChunkRange &chunk, int64_t &hv)
    {
        const int64_t workId = PackWorkId(base, nThis, taskIdx);
        hv = workId % HV;
        chunk = GetChunkRange(*this, gmCu, gmIdx, workId / HV);
    }

    __aicore__ inline bool PackHasTail(int64_t base, int64_t nThis)
    {
        for (int64_t t = 0; t < nThis; ++t) {
            if (GetChunkRange(*this, gmCu, gmIdx, PackWorkId(base, nThis, t) / HV).M < chunkSize) {
                return true;
            }
        }
        return false;
    }

    __aicore__ inline bool PackHasTail(const PackWalk &w)
    {
        return PackHasTail(w.base, w.nThis);
    }

    __aicore__ inline void DrainPackWuToGm(int64_t base, int64_t nThis)
    {
        for (int64_t t = subBlock; t < nThis; t += 2) {
            ChunkRange chunk;
            int64_t hv;
            DecodeTask(base, nThis, t, chunk, hv);
            CopyUbToGmElems(gmW[OffsetBHTD(chunk.batch, hv, chunk.tokenStart, HV, T, K)],
                            ubS7W[PingPongSlot(t)], static_cast<uint32_t>(chunk.M * K));
            if (V <= kGdnHeadDimK) {
                CopyUbToGmElems(gmU[OffsetBHTD(chunk.batch, hv, chunk.tokenStart, HV, T, V)],
                                ubS7U[PingPongSlot(t)], static_cast<uint32_t>(chunk.M * V));
            }
        }
    }

    __aicore__ inline void ProcessAiv()
    {
        Stage0_GenerateResidentAux();

        const int64_t packSize = TasksPerPack();
        const int64_t nPacks = CeilDiv(totalChunks, packSize);
        for (int64_t pack = coreIdx; pack < nPacks; pack += numCore) {
            const PackWalk cur = MakePackWalk(pack, packSize);
            PackWalk prev{};
            if (pack != coreIdx) {
                prev = MakePackWalk(pack - numCore, packSize);
            }
            if (pack != coreIdx) {
                if (PackHasTail(cur) || PackHasTail(prev)) {
                    WaitAicStage7Done();
                }
            }
            for (int64_t t = subBlock; t < cur.nThis; t += 2) {
                ChunkRange chunk;
                int64_t hv;
                DecodeTask(cur.base, cur.nThis, t, chunk, hv);
                Stage1_OneTask(chunk, hv, t);
            }
            SetFlag<HardEvent::MTE3_V>(kHeUb0);
            WaitFlag<HardEvent::MTE3_V>(kHeUb0);
            for (int64_t t = subBlock; t < cur.nThis; t += 2) {
                Stage3_PrepareGate(t);
            }
            for (int64_t t = subBlock; t < cur.nThis; t += 2) {
                Stage3_AivOne(PackWorkId(cur.base, cur.nThis, t) % HV, t);
            }
            if (pack != coreIdx) {
                DrainPackWuToGm(prev.base, prev.nThis);
            }
            SetFlag<HardEvent::MTE3_MTE2>(kHeUb0);
            WaitFlag<HardEvent::MTE3_MTE2>(kHeUb0);

            for (int64_t t = subBlock; t < cur.nThis; t += 2) {
                ChunkRange chunk;
                int64_t hv;
                DecodeTask(cur.base, cur.nThis, t, chunk, hv);
                Stage6_AivOne(chunk, hv, t);
                NotifyAicStage6Done(t);
            }
        }
        if (coreIdx < nPacks) {
            const int64_t pack = coreIdx + (nPacks - 1 - coreIdx) / numCore * numCore;
            const PackWalk last = MakePackWalk(pack, packSize);
            WaitAicStage7Done();
            DrainPackWuToGm(last.base, last.nThis);
        }
    }

    __aicore__ inline void ProcessAic()
    {
        SetFlag<HardEvent::M_MTE1>(0);
        SetFlag<HardEvent::M_MTE1>(1);
        SetFlag<HardEvent::FIX_M>(0);
        SetFlag<HardEvent::FIX_M>(1);
        SetFlag<HardEvent::FIX_MTE1>(0);
        const int64_t packSize = TasksPerPack();
        for (int64_t t = 0; t < packSize; ++t) {
            NotifyAivStage4Done(t);
        }
        const int64_t nPacks = CeilDiv(totalChunks, packSize);
        for (int64_t pack = coreIdx; pack < nPacks; pack += numCore) {
            const PackWalk cur = MakePackWalk(pack, packSize);
            WaitFlag<HardEvent::FIX_MTE1>(0);
            for (int64_t t = 0; t < cur.nThis; ++t) {
                if (!OwnsHk(PackWorkId(cur.base, cur.nThis, t) % HV)) {
                    continue;
                }
                WaitAivStage1Done(t);
                Stage2_AicOne(t, cur.nThis);
                if (HRatio > 1) {
                    NotifyKktSiblings(cur.base, cur.nThis, t);
                }
            }
            Stage4_PrefillI(cur.nThis);
            if (cur.nThis > 0) {
                WaitAivStage3Done(0);
                Stage4_AccIssue(0);
                for (int64_t t = 1; t < cur.nThis; ++t) {
                    WaitAivStage3Done(t);
                    Stage4_AccIssue(t);
                    Stage4_Dump(t - 1);
                }
                Stage4_Dump(cur.nThis - 1);
            }
            if (cur.nThis > 0) {
                for (int64_t t = 0; t < cur.nThis; ++t) {
                    WaitFlag<HardEvent::MTE2_MTE1>(t);
                    Stage5_Compute(t);
                    ChunkRange chunk;
                    int64_t hv;
                    DecodeTask(cur.base, cur.nThis, t, chunk, hv);
                    Stage5_Dump(chunk, hv, t);
                }
            }
            for (int64_t t = 0; t < cur.nThis; ++t) {
                WaitAivStage6Done(t);
                ChunkRange chunk;
                int64_t hv;
                DecodeTask(cur.base, cur.nThis, t, chunk, hv);
                if (outputA != 0 && chunk.M == chunkSize) {
                    WaitFlag<HardEvent::MTE2_MTE1>(t);
                } else {
                    WaitFlag<HardEvent::FIX_MTE1>(t);
                }
                Stage7_AicOne(chunk, hv, t);
            }
            const int64_t nextPack = pack + numCore;
            if (nextPack < nPacks) {
                const PackWalk nxt = MakePackWalk(nextPack, packSize);
                if (PackHasTail(cur) || PackHasTail(nxt)) {
                    NotifyAivStage7Done();
                }
            } else {
                NotifyAivStage7Done();
            }
            SetFlag<HardEvent::FIX_MTE1>(0);
        }
    }

    __aicore__ inline void Process()
    {
        if ASCEND_IS_AIV {
            ProcessAiv();
        }
        if ASCEND_IS_AIC {
            ProcessAic();
        }
    }

private:
    // GM
    // Input
    GlobalTensor<InDtype> gmQ;
    GlobalTensor<InDtype> gmK;
    GlobalTensor<InDtype> gmV;
    GlobalTensor<GateDtype> gmG;
    GlobalTensor<GateDtype> gmBeta;
    GlobalTensor<ALogDtype> gmALog;
    GlobalTensor<ALogDtype> gmDt;
    // Output
    GlobalTensor<InDtype> gmQHat;
    GlobalTensor<InDtype> gmKHat;
    GlobalTensor<InDtype> gmW;
    GlobalTensor<InDtype> gmU;
    GlobalTensor<InDtype> gmA;
    GlobalTensor<float> gmQRstd;
    GlobalTensor<float> gmKRstd;
    GlobalTensor<float> gmGOut;
    GlobalTensor<float> gmBetaEff;
    // Workspace
    GlobalTensor<float> gmWsY;

    // Local
    // UB
    // S0
    LocalTensor<uint32_t> ubVcsIdx;
    LocalTensor<float> ubIVcs, ubS0Zero;

    // S1
    LocalTensor<float> ubGPrime[2], ubBetaEff[2];
    LocalTensor<InDtype> ubQ[2], ubK[2], ubQHat[2], ubKHat[2];
    LocalTensor<float> ubKRstd[2], ubQRstd[2];

    // S2
    LocalTensor<float> ubKkt[2];

    LocalTensor<float> ubLPacked[2], ubResVcs[2], ubLFull[2];

    LocalTensor<InDtype> ubS6K[2], ubS6V[2];
    LocalTensor<InDtype> ubS7W[2], ubS7U[2];

    // L1
    LocalTensor<float> l1I;
    LocalTensor<InDtype> l1KHat[4], l1A[4], l1Kbg[4], l1Vb[4], l1Vb1[4];
    LocalTensor<float> l1NegL[4], l1LeafRight[4], l1LeafLeft[4], l1Y[4];

    // L0
    LocalTensor<InDtype> l0A[2], l0B[2], l0AS7[2], l0BS7[2];
    LocalTensor<float> l0Af[2], l0Bf[2], l0AfP[2], l0BfP[2], l0CS7[2];
    LocalTensor<float> l0CTask[4];

    int64_t hasBetaOut;
};

} // namespace ChunkGatedDeltaRuleFwdPrepare

#endif
